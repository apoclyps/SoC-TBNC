-- MySQL SCHEMA - Kyle Harrison
--
-- Host: arlia.computing.dundee.ac.uk   	Database: 12ac3d16
-- User: 12ac3u16       	 				Password: 111aaa 
-- ------------------------------------------------------
-- Tested on Server version	5.5.27 - MySQL Community Server 

USE 12ac3d16;

CREATE USER admin [IDENTIFIED BY [PASSWORD] '139003026163048163140058083026136144198161086060']